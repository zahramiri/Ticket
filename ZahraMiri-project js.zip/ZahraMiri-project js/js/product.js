
let priceArr = [];
const container = document.getElementById('product-container');
fetch("https://fakestoreapi.com/products")
.then(response => response.json())
.then(data => {
    data.forEach(product => {
        // const cardContainer = document.getElementById('card-container');
        // cardContainer.innerHTML = ''; 
        const productCard = `
            <div class="col-md-4">
                <div class="card product-card">
                    <img class="card-img-top" height="300" src="${product.image}" alt="${product.title}">
                    <div class="card-body">
                       <h5 class="card-title">${product.title}</h5>
            
                       <h3 class="card-text" color=>${product.price}<h3>
                       <button class="btn btn-primary" onclick="getProductData('${product.title}', '${product.price}')">Add to Cart</button>
                    </div>
                </div>
            </div>`;
        container.innerHTML += productCard;
    });
    
})
.catch(error => console.error('Error fetching data:', error));

AllProducts = (e) =>{ 
    let val = e.value;
    container.innerHTML = '';
    if(val=='All Category'){
        var api="https://fakestoreapi.com/products"
    }else{
       var api=`https://fakestoreapi.com/products/category/${val}`
    }
    container.innerHTML = '';
    container.innerHTML = '';
fetch(api)
.then(response => response.json())
.then(data => {
debugger
data.forEach(product => {
   const productCard = `
      <div class="col-md-4">
         <div class="card product-card">
            <img class="card-img-top" height="200" src="${product.image}" alt="${product.title}">
            <div class="card-body">
               <h5 class="card-title">${product.title}</h5>
               <p class="card-text">${product.description}</p>
               <h3 class="card-text" color=>${product.price}<h3>
               <button class="btn btn-primary" onclick="getProductData('${product.title}', '${product.price}')">Add to Cart</button>
            </div>
         </div>
      </div>`;
   container.innerHTML += productCard;
})
.catch(error => console.error('Error fetching data:', error))})};
     
allpro =(e) =>{
   container.innerHTML = '';
   let val = e.value;
   fetch("https://fakestoreapi.com/products")
   .then(response => response.json())
   .then(data => {
      data.forEach(product => {
       if(product.price<val){
       console.log(product);
       const productCard = `
         <div class="col-md-4">
            <div class="card product-card">
               <img class="card-img-top" height="300" src="${product.image}" alt="${product.title}">
               <div class="card-body">
                  <h5 class="card-title">${product.title}</h5>
                  <p class="card-text">${product.description}</p>
                  <h3 class="card-text" color=>${product.price}<h3>
                  <button class="btn btn-primary" onclick="getProductData('${product.title}', '${product.price}')">Add to Cart</button>
               </div>
            </div>
         </div>`;
       container.innerHTML += productCard;
      }});
      
 })
 .catch(error => console.error('Error fetching data:', error))
 }

 function getProductData(title, price) {
   const div=document.createElement('div')
   const ul=document.createElement('ul')
   ul.className = 'list-group-item';
   ul.textContent = `${title} - ${price}`;
   div.appendChild(ul);
   const local=JSON.stringify(div)
   let cart = JSON.parse(localStorage.getItem('cart')) || [];
   cart.push({ title, price });
   localStorage.setItem('cart', JSON.stringify(cart));
 }
 let category=document.getElementById('category')
 fetch("https://fakestoreapi.com/products/categories")
 .then(response => response.json())
 .then(data => {
   let categoryData = data;
   categoryData.forEach(cat => {
    let opt = document.createElement('option');
    opt.setAttribute('value', `${cat}` );
    opt.innerText = `${cat}`;
    category.append(opt);
   });
 })

 document.getElementById('priceRange').addEventListener('input', function() {
 document.getElementById('priceValue').textContent = this.value;
 });
  

