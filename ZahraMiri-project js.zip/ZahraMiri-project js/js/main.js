
const apiUrl = 'https://fakestoreapi.com/products';
const maxlength=20;
fetch(apiUrl)
    .then(response => response.json())
    .then(data => {
        const container = document.getElementById('product-container');
        
        data.slice(14,20).forEach(product => {
            if(product.description>maxlength)
                {
                   let x =product.description.slice
                }
            const productCard = `
                <div class="col-md-4">
                    <div class="card product-card">
                        <img class="card-img-top" height="300" src="${product.image}" alt="${product.title}">
                        <div class="card-body">
                            <h5 class="card-title">${product.title}</h5>
                            <a href="product.html" class="btn btn-primary">Add to Cart</a>
                        </div>
                    </div>
                </div>`;
            container.innerHTML += productCard;
        });
    })
    .catch(error => console.error('Error fetching data:', error));

