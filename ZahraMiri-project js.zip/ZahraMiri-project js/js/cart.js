

const cartItems = JSON.parse(localStorage.getItem('cart'));
const cartTableBody = document.getElementById('cartItems');
let totalPrice = 0;
console.log(cartItems)
cartItems.forEach(item => {
    const row = document.createElement('tr');
    const titleCell = document.createElement('td');
    const priceCell = document.createElement('td');
    const delCell = document.createElement('td');
    titleCell.textContent = item.title;
    priceCell.textContent = item.price;
    delCell.textContent = 'delete';
    delCell.style.cursor = 'pointer';
    delCell.addEventListener('click',(e)=>{
        debugger;
        console.log(e)
        const index = cartItems.indexOf(item);
        if (index > -1) {
            cartItems.splice(index, 1);
            // totalPrice -= item.price; 
            // total.textContent = NumbertotalPrice; 
            row.remove();
            
        }

   })
   totalPrice += Number(item.price);

   row.appendChild(titleCell);
   row.appendChild(priceCell);
   row.appendChild(delCell);
   cartTableBody.appendChild(row);
});
const total=document.getElementById('totalPrice')
total.textContent = Math.round(totalPrice) ;

document.getElementById('resetButton').addEventListener('click', function() {
    cartTableBody.innerHTML=''
    total.innerHTML=0
});

deletHandler = (e) =>{
    cartItems

    let parent = e.parentElement.parentElement;
    let price = Number(parent.children[1].innerText);
    parent.remove();
    totalPrice -= price;
    const total = document.getElementById ('totalPrice')
    total.textContent = Math.round(totalPrice);
    
    let title = e.parentElement.parentElement.children[0].innerText;

    cartItems.forEach((elm)=>{
        if(title == elm.title){
            
        }
    })
}

